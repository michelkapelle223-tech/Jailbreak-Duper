import os

import discord
from discord import app_commands
from discord.ext import commands

TOKEN = os.getenv("DISCORD_BOT_TOKEN")

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)


class SubmitPowerShellButton(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Submit PowerShell",
        style=discord.ButtonStyle.secondary,
        custom_id="jailbreak_dupes:submit_powershell",
    )
    async def submit_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ):
        # Safe placeholder: this bot does not collect or execute PowerShell.
        await interaction.response.send_message(
            "For your safety, don't paste or run PowerShell commands from "
            "strangers. This bot does not collect or execute scripts.",
            ephemeral=True,
        )


@bot.event
async def on_ready():
    # Register the persistent button after the bot starts.
    bot.add_view(SubmitPowerShellButton())
    try:
        synced = await bot.tree.sync()
        print(f"Logged in as {bot.user}. Synced {len(synced)} command(s).")
    except discord.HTTPException as exc:
        print(f"Could not sync commands: {exc}")


@bot.tree.command(
    name="jailbreakdupes",
    description="Post the Jailbreak Dupes information embed.",
)
@app_commands.checks.has_permissions(manage_messages=True)
async def jailbreakdupes(interaction: discord.Interaction):
    embed = discord.Embed(
        title="Jailbreak Dupes",
        description=(
            "**Please enter the powershell you copied By clicking the button "
            "below to dupe your Jailbreak items.**\n\n"
            "**If you have not watched the tutorial please Watch the attached "
            "to understand the steps.**\n\n"
            "If your Item that you wanted duped did not appear, Please resubmit!."
        ),
        color=discord.Color.from_rgb(35, 36, 40),
    )

    await interaction.response.send_message(
        embed=embed,
        view=SubmitPowerShellButton(),
    )


@jailbreakdupes.error
async def jailbreakdupes_error(
    interaction: discord.Interaction,
    error: app_commands.AppCommandError,
):
    if isinstance(error, app_commands.MissingPermissions):
        message = "You need the **Manage Messages** permission to use this command."
    else:
        message = "Something went wrong while posting the embed."
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


if not TOKEN:
    raise RuntimeError(
        "Set the DISCORD_BOT_TOKEN environment variable before starting the bot."
    )

bot.run(TOKEN)
