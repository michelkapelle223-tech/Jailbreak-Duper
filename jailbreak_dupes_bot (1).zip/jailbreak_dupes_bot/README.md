# Jailbreak Dupes Discord bot

This bot posts an embed styled like the supplied screenshot.

## What it does
- `/jailbreakdupes` posts the **Jailbreak Dupes** embed and a grey **Submit PowerShell** button.
- The button replies privately with a safety notice.
- It does **not** collect, run, or forward PowerShell scripts.

## Setup
1. Install Python 3.10 or newer.
2. Create a bot in the Discord Developer Portal: https://discord.com/developers/applications
3. Under **Bot**, create/reset the bot token. Keep it secret.
4. Under **OAuth2 → URL Generator**, select `bot` and `applications.commands`.
5. Give it the permissions `Send Messages` and `Embed Links`, then invite it to your server.
6. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

7. Set your bot token as an environment variable.

   **Windows PowerShell:**
   ```powershell
   $env:DISCORD_BOT_TOKEN = "PASTE_YOUR_BOT_TOKEN_HERE"
   python bot.py
   ```

   **macOS/Linux:**
   ```bash
   export DISCORD_BOT_TOKEN="PASTE_YOUR_BOT_TOKEN_HERE"
   python bot.py
   ```

8. In your server, run `/jailbreakdupes`. You need **Manage Messages** permission.

## Screenshot matching
Set the bot's server nickname to `Jailbreak Duper` and upload your chosen avatar in the Developer Portal. Discord controls the avatar and the small `APP` label; the bot cannot set those from this script.
